package net.ug.hibernate;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class DaoReserva {
	protected SessionFactory sessionFactory;
	
	protected void setup() {
		final StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
				.configure()  //lee los settings del archivo hibernate.cfg.xml
				.build();
		try {
			sessionFactory = new MetadataSources(registry)
					.buildMetadata().buildSessionFactory();			
		} catch (Exception e) {
			StandardServiceRegistryBuilder.destroy(registry);
		}
		
	}
	
	protected void crear(Reserva reserva) {
		Session s =  sessionFactory.openSession();
		s.beginTransaction();
		s.save(reserva);
		s.getTransaction().commit();
		s.close();
	}
	
	protected Reserva read(long id_reserva) {
		Session s =  sessionFactory.openSession();
		Reserva reserva = s.get(Reserva.class, id_reserva);
		s.close();
		return reserva;
	}
	
	protected void update(Reserva reserva) {
		Session s =  sessionFactory.openSession();
		s.beginTransaction();
		s.update(reserva);
		s.getTransaction().commit();
		s.close();
	}
	
	
	protected void delete(int id_reserva) {
		Session s =  sessionFactory.openSession();
		s.beginTransaction();
		Reserva book = new Reserva();
		book.setId(id_reserva);
		s.delete(id_reserva);
		s.getTransaction().commit();
		s.close();
	}

}
