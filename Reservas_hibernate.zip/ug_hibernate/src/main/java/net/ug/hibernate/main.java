package net.ug.hibernate;

public class main {
	
	
	public static void main(String[] args) {
		crear_reserva();
		leer_reserva();
		actualizar_reserva();
		eliminar_reserva();
	}
	
	public static void crear_reserva() {
		DaoReserva daoreserva = new DaoReserva();
		Reserva reserva = new Reserva(1,"12/05/19","13/05/19","matrimonial",1,2,1);		
		daoreserva.setup();
		daoreserva.crear(reserva);
		reserva = new Reserva(1,"12/05/19","13/05/19","matrimonial",1,2,1);	
		daoreserva.crear(reserva);		
	}
	
	public static void leer_reserva() {
		DaoReserva daoreserva = new DaoReserva();
		daoreserva.setup();
		Reserva reserva = daoreserva.read(1);
	}

	public static void actualizar_reserva() {

		DaoReserva daoreserva = new DaoReserva();
		daoreserva.setup();
		Reserva reserva = daoreserva.read(1);
		reserva.setTipo_reserva("normal");
		daoreserva.update(reserva);
	}
	
	public static void eliminar_reserva() {
		DaoReserva daoreserva = new DaoReserva();
		daoreserva.setup();
		daoreserva.delete(1);
	}
}
