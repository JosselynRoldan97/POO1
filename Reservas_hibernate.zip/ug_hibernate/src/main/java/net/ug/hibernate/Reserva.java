package net.ug.hibernate;

import javax.persistence.*;

@Entity
@Table(name = "reserva")
public class Reserva {
	@Id
	@Column(name = "id_reserva")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(name = "Reservas")
	private String fecha_entrada;
	private String fecha_salida;
	private String tipo_reserva;
	private long id_cliente;
	private long id_tipo_habitacion;
	private long id_servicio;

	public Reserva(long id, String fecha_entrada, String fecha_salida, String tipo_reserva, long id_cliente,
			long id_tipo_habitacion, long id_servicio) {
		super();
		this.id = id;
		this.fecha_entrada = fecha_entrada;
		this.fecha_salida = fecha_salida;
		this.tipo_reserva = tipo_reserva;
		this.id_cliente = id_cliente;
		this.id_tipo_habitacion = id_tipo_habitacion;
		this.id_servicio = id_servicio;
	}

	public Reserva() {
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFecha_entrada() {
		return fecha_entrada;
	}

	public void setFecha_entrada(String fecha_entrada) {
		this.fecha_entrada = fecha_entrada;
	}

	public String getFecha_salida() {
		return fecha_salida;
	}

	public void setFecha_salida(String fecha_salida) {
		this.fecha_salida = fecha_salida;
	}

	public String getTipo_reserva() {
		return tipo_reserva;
	}

	public void setTipo_reserva(String tipo_reserva) {
		this.tipo_reserva = tipo_reserva;
	}

	public long getId_cliente() {
		return id_cliente;
	}

	public void setId_cliente(long id_cliente) {
		this.id_cliente = id_cliente;
	}

	public long getId_tipo_habitacion() {
		return id_tipo_habitacion;
	}

	public void setId_tipo_habitacion(long id_tipo_habitacion) {
		this.id_tipo_habitacion = id_tipo_habitacion;
	}

	public long getId_servicio() {
		return id_servicio;
	}

	public void setId_servicio(long id_servicio) {
		this.id_servicio = id_servicio;
	}

}